#coding=utf-8

print("----------多态----------")

#多态：（爆米花例子）相同的机器，不同的粮食表现不同的呈现方式
#定义的时候，可能调用的是子类的对象，也是定义可能是父类的对象

class F1(object):
    def show(self):
        print('F1.show')

class S1(F1):
    def show(self):
        print('S1.show')
              
class S2(F1):
    def show(self):
        print('S2.show')
        
# func 函数需要接收一个 F1 类型或者 F1 子类(S1,S2)的类型
def func(obj):

    obj.show()
    
S1_obj = S1()
func(S1_obj) #在 func 中传入S1 的对象，执行 S1 的 show方法

S2_obj = S2()
func(S2_obj) #在 func 中传入S2 的对象，执行 S2 的 show方法

