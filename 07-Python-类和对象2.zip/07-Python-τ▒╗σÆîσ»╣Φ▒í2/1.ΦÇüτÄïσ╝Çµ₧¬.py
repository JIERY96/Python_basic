#coding=utf-8

print("------------老王开枪-------------")

class Person:
    def __init__(self,name):
        self.name = name
        self.blood = 100
        self.gun = None
    
    def __str__(self):
        return self.name + '剩余的血量为:' +str(self.blood)
        
    def PutBullet(self, clip, bullet):
        clip.takeBullet(bullet)
        
    def PutClip(self,gun, clip):
        gun.takeClip(clip)
    
    def takeGun(self,gun):
        self.gun = gun
        
    def shot(self,SB):
        self.gun.shoting(SB)
        
    def bloodIncrease(self,demageLevel):
        if self.blood >0:
            self.blood -= demageLevel
        else:
            print('敌人已经死了，确定要开枪吗')
        

class Clip:

    def __init__(self,contain):
        self.contain = 20
        self.containList = []
        
    def takeBullet(self, bullet):
        if len((self.containList)) < self.contain:
            self.containList.append(bullet)
            
    def __str__(self):
        return "弹夹当前的子弹数量为:" + str(len(self.containList)) + '/' + str((self.contain))
        
    def prepareBullet(self):
        #判断当前弹夹是否有子弹
        if len(self.containList) > 0:
            bullet = self.containList[-1]#拿最后一颗子弹
            self.containList.pop()
            return bullet
        else:
            return None

class Bullet:
    
    def __init__(self,demageLevel):
        self.demageLevel = demageLevel
    
    def demage(self,SB):
        SB.bloodIncrease(self.demageLevel)

class Gun:

    def __init__(self):
        self.clip = None

    def takeClip (self, clip):
        if not(self.clip):
            self.clip = clip
            
    def __str__(self):
        if self.clip:
            return "弹夹已上膛"
        else:
            return "枪没有弹夹"
            
    def shoting(self,SB):
        self.clip.prepareBullet()
        if bullet:
            bullet.demage(SB)
        else:
            print('没有子弹了')    
    
    
#创建老王
LaoWang = Person("老王")

#创建弹夹
clip = Clip(20)
print(clip)

i = 0
while i<15:
    #创建子弹
    bullet = Bullet(10)
    LaoWang.PutBullet(clip, bullet)
    i +=1
print(clip)

#创建枪
gun = Gun()
print(gun)
LaoWang.PutClip(gun, clip)
print(gun)

#创建一个敌人
SB = Person("敌人")
print(SB)
print(clip)

#老王拿枪
LaoWang.takeGun(gun)

i = 0
while i < 11:
    #老王开枪
    LaoWang.shot(SB)
    print(SB)
    print(clip)
    i +=1



