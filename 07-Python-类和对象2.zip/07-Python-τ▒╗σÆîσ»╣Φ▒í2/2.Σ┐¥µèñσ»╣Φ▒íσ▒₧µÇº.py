#coding=utf-8

print("------------保护对象属性-------------")

class Person:

    def __init__(self,name,age):
        #只要属性名前面有俩个下划线，就表示是‘私有属性’
        #原来没有添加__的属性，默认是 ‘共有属性’
        self.__name = name
        self.__age = age
    
    # 属性的 set 方法    
    def setNewAge(self,newAge):
        if newAge>0 and newAge< 100:
            self.__age = newAge
    
    # 属性的 get 方法
    def getNewAge(self):
        return self.__age
                  
laowang = Person('老王',30)
#laowang.age +=1 #这种方式修改属性是不安全的
laowang.setNewAge(31)
age = laowang.getNewAge()
print(age)
#私有属性：不能在外部使用，对象名.get方法 获取到
#用私有属性：在类内部设置属性的set 和 get 方法，然后外部就可以用了

