#coding=utf-8

print("----------继承-多继承----------")

class Ma:
    def run(self):
        print('====10km/h===')
        
    def jiao(self):
        print('====马在叫====')

class Lv:
    def take(self):
        print('====驼物品====')
    
    def jiao(self):
        print('====驴在叫====')
        
class Luozi(Ma,Lv):
    pass
    

luozi = Luozi()
luozi.run()
luozi.take()
luozi.jiao() # 谁()在前面，就调用谁的方法
print(Luozi.__mro__) # mro算法可以显示目前有多少类是父类
