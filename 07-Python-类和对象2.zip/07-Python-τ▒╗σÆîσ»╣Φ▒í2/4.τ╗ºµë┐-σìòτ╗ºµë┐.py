#coding=utf-8

print("------------继承(单继承)-------------")

#继承：父类的属性和方法，子类都可以使用
#使用继承的场景： 俩个类若出现很多相似的功能，然后可以把这些方法/属性放到一个类里面，开始的俩个类只要继承就可以了

class Cat(object):
    def run(self):
        print('runing.....')


class Bosi(Cat):
    def run(self):
        print('跑。。。。。')
   
    
class Jiafei(Cat):
    def run(self):
        print('跑。。。。。')  
    

bosi = Bosi()
bosi.run()

#父类的私有方法或私有属性，在子类中是不可以用的
