#coding=utf-8

print("----------类方法/静态方法----------")

#类方法：对类的属性进行修改
class Test():
    #类属性
    num =10
    
    #实例方法
    def __init__(self):
        #实例属性
        self.age = 1
        
    @classmethod  #类方法 
    def setNum(cls, newNum):
        cls.num = newNum
    
    @staticmethod #静态方法
    def printLine(): #实例方法一定要 'self',不写self就用静态方法
        print('当前这个方法，没啥用，哈哈哈！')
       
a  = Test()
print(Test.num)
Test.setNum(300)
print(Test.num)  #注意：类名是访问不到实例方法里面的属性和方法的

Test.printLine() #调静态方法
# 总结： 实例属性用实例方法修改！ 类属性用类方法修改！
