#coding=utf-8

print("------------'——del——()方法'-------------")

# ——del——方法: 当对象即将被摧毁之前要做一些事情的方法

class Person:

    def __init__(self,name,age):
        self.__name = name
        self.__age = age
      
    #析构方法（当对象被删除时，会被自动调用）  
    def __del__(self):
        print('被调用了')
    
laowang = Person('老王',30)
laozhang = laowang
print(laozhang)
print(laowang)
del laowang #(手动删除) Python 有自动回收垃圾的机制

print('hahahahaha')
print(laozhang)
print(laowang) #因为laowang 这个对象被删除了，所以不能够再次使用
