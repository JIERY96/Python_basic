面试题（一）：

总结：
１．类方法：修改类属性的方法
２．静态方法：和类没有太大联系但想放在类里面，就在类中定义一个静态方法
３．调用实例方法：　对象．实例方法名
４．调用类方法：　类名．类方法名　or 　对象．类方法名
５．调用静态方法：　类名．静态方法名　or  对象．静态方法名

------------------------６．替换字符串-------------------------
#原型方法：
pstr = 'hello jiery'
afterReplace = strreplace(pstr, 'hello','jiery')

#方法一：(可替换全部相同字符)
pStr = "hello world"
def myReplace(pStr,oldStr, newStr):
    result = pStr.split(oldstr)
    return newStr.join(result)

a = myReplace(pStr, "world","jiery") 

#方法二：(只替换一个，想替换多个，加while True:)
position = pstr.find(oldStr)
pstr = pstr.[:position] + newStr +[position+len(oldStr):]
return pstr
-------------------------------------------------------------

面试题　(二)：

１．Python中用＇＃＇注释，用＇＇＇做特别注释
２．一行写不开的话，可以用 \ 

３．多条语句可以用；隔开．ｅｇ： a = 10; b = 20; c= 30
４．每个python的py文件都可以是一个模块.[import or from x import 　　　　全局变量/类/函数/］

５．Python　所有对象的三大特性：继承，封装，多态
６．Python 的数字类型分为：int, float, long,complex
７．Python 的序列类型分为：列表，元祖，字典；字典是唯一的映射类型
８．Python 的标准类型内建函数有：print,input,open,str,等等

９．设 s = 'abcdefg', s[3]= d, s[3:5] = de, s[:5] = abcde ,s[3:] = defg, s[::2] = aceg, s[::-1] = gfedcba ,s[-2:-5] = ''

１０．删除字典中所有元素的函数是：clear(), 从一个字典的内容添加另外一个字典的函数是：a.update(b). 

１１．类生成对象，所有的方法放在类中，创建对象的过程：调用__new__() 去开辟内存空间，返回的内存空间传给__init__()方法．当这来个方法都做完的时候，然后才把一个对象给一个变量名

------------------------１2.重组 list------------------------
将[1,2,3,4,5,6...100] 如何转变成[[1,2,3],[4,5,6],[7,8,9]...]?

a = [x for x in range(101)]
b = [a[i: i+3] for i in range(1,len(a),3)]
print(b)
-------------------------------------------------------------


----------------------13.删除list重复元素---------------------
a = [11,22,33,44,55,11]
b = set(a)
c = list(b)
print(c)
-------------------------------------------------------------


-----------------------14.交换 a, b 的值----------------------
#方法一：
a = 9
b = 8
a,b = b,a

#方法二:
a = a + b
b = a - b
a = a - b
-------------------------------------------------------------


-----------------------------列表----------------------------
写个函数，给定参数n,生成含有n个元素值为1~n 的列表，顺序随机，值可重复

def test(n):
    newList = []
    i = 0
    while True:
        if len(newList) = 10:
            break
            
        num = random.randint(1,n)
        if num not in newList
            newList.append(num)
        
    return newList
-------------------------------------------------------------


