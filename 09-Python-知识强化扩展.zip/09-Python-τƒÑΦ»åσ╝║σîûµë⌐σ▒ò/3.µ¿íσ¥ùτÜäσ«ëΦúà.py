#coding-utf-8

print('-----------模块的安装------------')

#　１．找到模块的压缩包

#　２．解压　

#　３．进入终端执行命令 sudo python setup.py install

# 在　install 的时候，执行目录安装

# 　4．安装完就可以使用了，记得是当前目录哦
