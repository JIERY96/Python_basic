
from distutils.core import setup

setup (name='jiery',version = '1.0', description= 'jiery model', author = 'jiery',py_modules= ['suba.a','suba.b','subb.c','subb.d'])
