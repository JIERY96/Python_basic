#coding-utf-8
print('--------------列表推导式---------------')

a = [x for x in [11,22,33,44,55]]
print(a)

for x in range(1,5): #从１开始取值，可以取到(5-1)
    print(x)
       
for x in range(5): #默认０开始，取到＜5的值
    print(x)
    
for x in range(1,8,2): #每次递归加２
    print(x)

a = [ x for x in range(1,10)]  # 将 1-100 写在列表内
print(a)

a = [ x for x in range(1,10,2)]  # 将 1-100 写在列表内
print(a)

a = [x for x in range(0,10,2) if x%2 ==0 ] # 偶数
print(a)

a = [(x,y) for x in range(1,4) for y in range(1,3)]#生成坐标
print(a)#[for嵌套]: 第一个for执行一次，第二个for执行俩次.2*3=6次

#range往往和for循环配合使用 
