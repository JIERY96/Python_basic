
from distutils.core import setup

setup (name='jiery',version = '1.0', description= 'jiery model', author = 'jiery',py_modules= ['suba.a','suba.b','subb.c','subb.d'])



#１ 准备好要发布的文件以后，建一个'setup.py'文件里面写上面具体的内容

#2 打开终端：回到在你文件的当前目录下，输入 python setup.py bulid

#3 此时，你的当前目录会多一个build 的文件

#4 然后继续在终端输入 python setup.py sdist

#5 然后当前目录多一个叫　dist 的目录，里面就是要上传的压缩包

