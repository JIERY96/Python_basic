#coding-utf-8
import sys

print('-----------程序的传参------------')

def B(num):

    print(num)
    
def A(num):
    print(num)
    B(100)
 
if sys.argv[1] == 'A':   #程序的传参就是解决　if xxx:　xxx的问题
    A(200) 
    
elif sys.argv[1] == 'B':
    B(300)
 

print(sys.argv) #结果是: ['4.py'] 

#　argv 就是一个列表　保存传进来的参数

#给程序传参数，例如 python3 4.py jiery. 结果就是 ['4.py'，jiery]

#作用：例如，python3 sendmsg.py 192.168.xx.xx(参数)

