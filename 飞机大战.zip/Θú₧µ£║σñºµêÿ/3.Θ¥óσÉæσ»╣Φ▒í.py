#coding=utf-8
import pygame

#导入按键的检测
from pygame.locals import *  

class HeroPlane(object):
    
    def __init__(self,screen):
        #设置飞机默认的位置
        self.x = 170
        self.y = 600
        #设置要显示内容的窗口
        self.screen = screen       
        
        self.imageName = './feiji/hero.gif'  
        self.image = pygame.image.load(self.imageName).convert()
        
        self.bullet = []
    
    def display(self):
        self.screen.blit(self.image,(self.x,self.y))  
    
    def moveLeft(self):
        self.x -= 10
        
    def moveRight(self):
        self.x += 10
        
    def shot(self):
        pass

if __name__ == '__main__':

    #1.创建一个窗口，用来显示内容
    screen = pygame.display.set_mode((440,745),0,32)
    
    #2.创建一个和窗口一样大的图片．显示背景
    backgro = pygame.image.load('./feiji/background.png').convert()
    
    #2.1 创建玩家飞机
    heroPlane = HeroPlane(screen)
    
    #3.把背景图片放在窗口中显示
    while True:
        screen.blit(backgro,(0,0))
        
        heroPlane.display()
        
        #判断是否点击了退出按钮
        for event in pygame.event.get():
            if event.type == QUIT:
                print("exit")
                exit()
            elif event.type == KEYDOWN:
                if event.key == K_LEFT:
                    print('left')
                    #控制飞机向左移动
                    heroPlane.moveLeft()
                    
                elif event.key == K_RIGHT:
                    print('right')
                    #控制飞机向右移动
                    heroPlane.moveRight()
                    
                elif event.key == K_SPACE:
                    print('space')
                    #发射子弹
                    heroPlane.shot()
                    
        pygame.display.update()
       
 

