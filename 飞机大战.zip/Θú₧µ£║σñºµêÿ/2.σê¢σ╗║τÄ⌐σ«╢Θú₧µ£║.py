#coding=utf-8
import pygame

#导入按键的检测
from pygame.locals import *     

if __name__ == '__main__':

    #1.创建一个窗口，用来显示内容
    screen = pygame.display.set_mode((440,745),0,32)
    
    #2.创建一个和窗口一样大的图片．显示背景
    backgro = pygame.image.load('./feiji/background.png').convert()
    
    #2.1 创建玩家飞机
    player = pygame.image.load('./feiji/hero.gif').convert()
    
    x = 0
    y = 0
    #3.把背景图片放在窗口中显示
    while True:
        screen.blit(backgro,(0,0))
        screen.blit(player,(x,y))
        
        #判断是否点击了退出按钮
        for event in pygame.event.get():
            if event.type == QUIT:
                print("exit")
                exit()
            elif event.type == KEYDOWN:
                if event.key == K_LEFT:
                    print('left')
                    #控制飞机向左移动
                    x-= 10
                    
                elif event.key == K_RIGHT:
                    print('right')
                    x+= 10
                elif event.key == K_SPACE:
                    print('space')
        pygame.display.update()
       
 

