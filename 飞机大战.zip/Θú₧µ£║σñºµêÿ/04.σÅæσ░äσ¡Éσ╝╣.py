#coding=utf-8
import pygame
import time
#导入按键的检测
from pygame.locals import *  

class HeroPlane(object):
    
    def __init__(self,screen):
        #设置飞机默认的位置
        self.x = 170
        self.y = 600
        #设置要显示内容的窗口
        self.screen = screen       
        
        self.imageName = './feiji/hero.gif'  
        self.image = pygame.image.load(self.imageName).convert()
        
        #用来存储玩家飞机发射的所有子弹
        self.bulletList = []
    
    def display(self):
        self.screen.blit(self.image,(self.x,self.y))
        
        for bullet in self.bulletList:
            bullet.bulletDisplay() 
            bullet.move()
            
    def moveLeft(self):
        self.x -= 10
        
    def moveRight(self):
        self.x += 10
        
    def shot(self):
        newBullet = Bullet(self.x, self.y,self.screen)
        self.bulletList.append(newBullet)

class Bullet(object):

    def __init__(self,x,y,screen):
        
        #子弹的位置要跟随这飞机的位置
        self.x = x + 40
        self.y = y - 17
        self.screen = screen
        self.img=pygame.image.load('./feiji/bullet.gif').convert()
    
    def bulletDisplay(self):
    
        self.screen.blit(self.img,(self.x,self.y)) 
        
    def move(self):
        self.y -=2


class EnemyPlane(object):
    
    def __init__(self,screen):
        #设置飞机默认的位置
        self.x = 0
        self.y = 0
        #设置要显示内容的窗口
        self.screen = screen       
        
        self.imageName = './feiji/enemy-1.gif'  
        self.image = pygame.image.load(self.imageName).convert()
        
        #用来存储玩家飞机发射的所有子弹
        self.bulletList = []
    
    def display(self):
        self.screen.blit(self.image,(self.x,self.y))
        

if __name__ == '__main__':

    #1.创建一个窗口，用来显示内容
    screen = pygame.display.set_mode((440,745),0,32)
    
    #2.创建一个和窗口一样大的图片．显示背景
    backgro =pygame.image.load('./feiji/background.png').convert()
    
    #2.1 创建玩家飞机
    heroPlane = HeroPlane(screen)
    
    #2.2 创建敌人飞机
    enemyPlane = EnemyPlane(screen)
    
    #3.把背景图片放在窗口中显示
    while True:
        screen.blit(backgro,(0,0))
        
        heroPlane.display()
        enemyPlane.display()
        
        #判断是否点击了退出按钮
        for event in pygame.event.get():
            if event.type == QUIT:
                print("exit")
                exit()
            elif event.type == KEYDOWN:
                if event.key == K_LEFT:
                    print('left')
                    #控制飞机向左移动
                    heroPlane.moveLeft()
                    
                elif event.key == K_RIGHT:
                    print('right')
                    #控制飞机向右移动
                    heroPlane.moveRight()
                    
                elif event.key == K_SPACE:
                    print('space')
                    #发射子弹
                    heroPlane.shot()
                                        
        pygame.display.update()
        time.sleep(0.01)

