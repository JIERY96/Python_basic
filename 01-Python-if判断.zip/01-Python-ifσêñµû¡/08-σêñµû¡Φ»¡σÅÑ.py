#coding=utf-8
#if -else 判断语句

print ("-------------判断语句-------------")

age = 18

if age>=18:
    print ("可以上网了")
else:
    print ("年龄太小了，过几年再来吧，我在网吧一直等你。。。")

