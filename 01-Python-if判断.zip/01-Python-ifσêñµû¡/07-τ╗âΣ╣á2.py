#coding=utf-8
#练习2

print ("-------------练习2-------------")

num1 = input ("Enter the frist number:")
num2 = input ("Enter the second number:")

result = int(num1) + int(num2)

print ("%s + %s = %d"%(num1, num2,result))
