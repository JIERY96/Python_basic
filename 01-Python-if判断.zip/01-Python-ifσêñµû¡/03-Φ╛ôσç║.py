#coding=utf-8
#输出

print ("-------------输出 1-------------")

print("名字：Jiery")
print("\n电话：188xxxxxxx")
print("\n地址：xxx")

'''
\n 换行显示
\t 相当于tab键
'''
print ("-------------输出 2-------------")

name = "shirui"
age =21
addr = "xxxxxx"

print (name+addr+str(age))
print ("我今年%d岁" %age) #格式化输出
print ("我的姓名是%s，我的年龄是%d岁" %(name,age))

#%s:字符串转化  %d:十进制整数 %f:浮点实数
