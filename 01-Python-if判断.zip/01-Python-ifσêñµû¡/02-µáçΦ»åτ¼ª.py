#coding=utf-8
#标识符

print ("-------------标识符-------------")

#一般以字母，数字和下划线组成，且不能以数字开头
#命名规则：驼峰命名法（myName/MyName/my_Nmae）

#Python 中的关键字
''' 
['and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'exec', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'not', 'or', 'pass', 'print', 'raise', 'return', 'try', 'while', 'with', 'yield']
'''

