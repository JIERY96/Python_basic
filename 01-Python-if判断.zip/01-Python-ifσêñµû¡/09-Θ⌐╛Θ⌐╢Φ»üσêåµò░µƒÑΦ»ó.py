#coding=utf-8
#if -else 练习

print ("-------------判断练习-------------")

# 1. 请输入你当前的分数
scoreInput = input ("请输入你的当前分数：")
score = int(scoreInput)

# 2. 请输入你违反的交通规则序号（1：闯红灯； 2： 违章停车）
rule = int(input("选择条款（1：闯红灯； 2： 违章停车):\n"))

# 3. 扣分
if rule == 1:
    score -= 6 
if rule == 2:
    score -= 3

# 4. 显示当前分数， 以及是否需要参加学习
print ("您的剩余分数%d："%score)
if score >= 2:
    print ("您不需要学习")
else:
    print ("您需要进行学习，祝您学习顺利")   
    
