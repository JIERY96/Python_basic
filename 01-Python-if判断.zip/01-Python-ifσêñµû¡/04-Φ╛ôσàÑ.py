#coding=utf-8
#输入

print ("-------------输入-------------")

#input ("请输入用户名:")

#把用户输入的值保存下来
userName = input ("请输入用户名:")

print ("您的名字是%s"%userName)
