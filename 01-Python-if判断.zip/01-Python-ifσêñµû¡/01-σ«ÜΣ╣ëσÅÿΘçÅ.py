#coding=utf-8
#定义变量
#名字 = 值

print ("-------------变量-------------")

name = 'shirui'

#第一个是定义一个变量
age = 30

print (name)

#第二个及以后都是使用这个变量
age = 21

print ('My age is :', age)
print ('My name is :', name)

#查看变量的类型
print (type(name))
print (type(age))


