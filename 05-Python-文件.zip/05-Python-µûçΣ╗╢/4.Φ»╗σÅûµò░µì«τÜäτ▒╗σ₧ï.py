#coding=utf-8
#读数据的类型

print("------------读取数据的类型-------------")

f = open ("jack.txt")

#r=f.readlines()#读取文件全部信息，且分行读取并在行之间用，隔开

r = f.readline()#每次只读一行

#r = f.read(1000) # （）内可以指定一个值

print(r)

