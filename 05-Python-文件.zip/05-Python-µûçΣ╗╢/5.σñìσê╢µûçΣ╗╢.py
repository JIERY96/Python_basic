#coding=utf-8
#对已经存在的文件进行复制

print("------------复制文件-------------")

#提示并获取要复制的文件名
name = input ("请输入要复制的文件名：")

#打开要复制的文件
f_read = open(name,"r")

#创建一个新的文件，用来存储原文件的数据内容
findPoint = name.rfind('.')
newName =name[:findPoint] +"[复制]" + name[findPoint:]
f_write = open (newName,"w")

#复制
#第一种
#content = f_read.read()
#f_write.write(content)
#第二种
#for linecontent in f_read.readlines():
#    f_write.write(linecontent)
#第三种
while True:
    linecontent = f_read.readline()
    if len(linecontent)>0:
        f_write.write(linecontent)
    else:
        break
    
#关闭
f_read.close()
f_write.close()
