#coding=utf-8
import os
#文件的操作

print("------------文件的操作-------------")

#os.rename("jack.txt","jackkkk.txt") #重命名文件名

#os.remove("jackkkk.txt") # 删除文件

os.mkdir("Shirui") #创建文件夹

path = os.getcwd() #获取当前路径
print(path)

l = os.listdir() #获取当前路径下的文件并返回
print(l)

#os.rmdir("shirui")
