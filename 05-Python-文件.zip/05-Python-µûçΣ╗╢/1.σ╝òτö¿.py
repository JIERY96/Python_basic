#coding=utf-8
#引用

print("------------引用-------------")

a = 100
b = a
print(id(a))
print(id(b))
a = 200
print(id(a))
print(id(b))


A = [11,22]
B = A
print(id(A))
print(id(B))
A.append(33)
print(id(A))
print(id(B))

#可变数据类型：列表，字典
#不可变数据类型： 数字，字符串，元祖 (不可变类型可以“哈希”)
M = {'score':3, 100:85, 3.14:31, (11,22):10086,}
print(M)

