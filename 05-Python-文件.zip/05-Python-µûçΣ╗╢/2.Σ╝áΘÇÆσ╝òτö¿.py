#coding=utf-8
#传递引用

print("------------传递引用-------------")

def test(a,b):
    a = a+a #先把a 取出来复制一份，然后把复制的那份放到新地址
    #a += a # 直接对原 a 直接修改
    print(id(a))
    print(a)
    
A = 100
B = 200

print(id(A))
test(A,B)

