#coding=utf-8
#文件的读写

print("------------文件的读写-------------")

#文件的读
'''
f = open("jiery.txt",'r')

strings = f.read()

print(strings)
'''

#文件的写
f = open("jack.txt",'w')

f.write("Hello, my name is jack! 2017-12-25")

f.close()

