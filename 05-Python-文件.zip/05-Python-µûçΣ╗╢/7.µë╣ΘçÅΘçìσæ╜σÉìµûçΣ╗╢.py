#coding=utf-8
import os
#批量重命名文件

print("------------批量重命名文件-------------")
'''
# 1. 获取指定路径下的所有文件
allFile = os.listdir("./shirui") #桌面下的文件夹
print(allFile)

# 2. 循环的方式 依次进行重命名
for name in allFile:
    os.rename('./shirui/'+name,'./shirui/' +'[jiery出品]-'+name)

# rename(old,new)
'''

# 升级版
needrename = input("请输入要批量命名的文件夹：")
allFile = os.listdir("./"+needrename) #桌面下的文件夹
for name in allFile:
    os.rename('./'+needrename+'/'+name, './'+needrename+"/"+'[jiery出品]-'+name)
