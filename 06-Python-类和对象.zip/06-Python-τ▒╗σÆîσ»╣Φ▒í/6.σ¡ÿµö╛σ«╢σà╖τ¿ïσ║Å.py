#coding=utf-8

print("--------------存放家具程序-------------")

class Home:

    def __init__(self, area):
        self.area = area
        self.containItems = []
    
    def __str__(self):
        msg = '现住房面积:' + str(self.area)
        
        #为了让没家具的时候不显示“家里的物品”
        if len(self.containItems) >0: 
        
            msg += "; "
            msg += "家里的物品:"
            for temp in self.containItems:
                           
# 核心代码!!!!!! msg += self.containItems[0].name  
                msg += temp.name +','
            
        msg = msg[:-1]#字符串切片，切掉最后一个家具后面的 ，
        return msg
    
    #添加一个新的家具到房间
    def addItems(self,item):
        #添加家具
        if self.area > item.area:
            self.containItems.append(item)
            self.area -= item.area
        else:
            print("房间没有空地可添加家具了")
class Bed:

    def __init__(self,name,area):
        self.name = name
        self.area = area
    
    def __str__(self):
        msg = self.name + "床的面积为:" + str(self.area)
        return msg
    
# 创建一个 “家” 对象
myhome = Home(128)
print(myhome)

mybed = Bed('席梦思',5)
print(mybed)
myhome.addItems(mybed)
print(myhome)

mybed2 = Bed('硬板床',6)
print(mybed2)
myhome.addItems(mybed2)
print(myhome)


