#coding=utf-8

print("------------‘魔法’方法------------")


class Dog:

    def __init__(self,color):
        self.color = color
        print(self.color)
        
    def changeColor(self,newColor):
        self.color = newColor
        print('颜色变为：%s'%self.color)
        
    def __str__(self):
        return "当前对象的颜色为:" + self.color #return 啥返回啥
            
WangCai = Dog('白')

WangCai.changeColor('黑')

print(WangCai) # 是一个地址
print('WangCai的内存地址为:%s'%id(WangCai))

#__str__ : 当打印类中所有的 ‘对象’的时候，立马变成__str__返回的东西
