#coding=utf-8

print("------------init方法-self------------")

class Dog:

    def __init__(self,color):
        self.color = color
        print(self.color)

    def bark(self):
        print("汪汪汪")
        
    def changeColor(self,newColor):
        self.color = newColor
        print('颜色变为：%s'%self.color)
            
WangCai = Dog('白')

#WangCai.color = 'yellow'
#a = WangCai.color
#print(a)

WangCai.changeColor('黑')

# 一个变量会指向一块空间
