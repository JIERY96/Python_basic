#coding=utf-8

print("------------烤地瓜程序------------")

class SweetPotato:
   
    #用来完成一些初始化的工作
    def __init__(self):
        self.cookedLevel = 0
        self.cookedString = '生的'
        self.condiments = []
    #方法
    def __str__(self):
    
        msg  = '生熟程度:' + self.cookedString
        msg += '; 等级为:' + str(self.cookedLevel)
        
        if len(self.condiments) >0: 
            msg += '; 口味:'#口味：芥末，孜然
            
            for temp in self.condiments:
                msg += temp + ',' 
            
            #msg = msg[:-1] #字符串切片，切掉最后一个口味的 ','
            msg = msg.strip(',') #切掉俩边的 ','
        else:
            msg += '; 原味地瓜'
        
        return msg
    
    # 烤地瓜的方法
    def cook(self,time):
        self.cookedLevel += time
        if self.cookedLevel>8:
            self.cookedString = '焦了'
        elif self.cookedLevel>5:
            self.cookedString = '熟了'
        elif self.cookedLevel>3:
            self.cookedString = '半熟'
        else:
            self.cookedString = '生的'
    # 添加作料
    def addCondiments(self,temp):
        self.condiments.append(temp)
            
diGua = SweetPotato()

diGua.cook(1)
print(diGua)

diGua.addCondiments('芥末')
print(diGua)

diGua.cook(5)
print(diGua)

diGua.addCondiments('咖喱')
print(diGua)

