#coding=utf-8

print("------------定义类-方法-------------")

#class 类名:   #类名定义规则：大驼峰
#    XXXXXXXX
class Cat:
    #属性  
    #方法
    def eat(self):
        print('======吃======')
    def printInfo(self):
        print(self.color)
              
xiaohuamao = Cat() #创建一个对象
xiaohuamao.eat() #调用类的方法
#添加属性
xiaohuamao.color = 'red'
xiaohuamao.weight = 5 #kg
#获取小花猫对象的属性
a = xiaohuamao.color
print(a)
print(xiaohuamao.weight)
xiaohuamao.printInfo()

#给一个对象添加属性的方法为：对象名.新的属性名 = 值
#获取对象的属性 2 种方法：
# 1. 对象.属性
# 2. 定义一个方法，在方法中使用 self.属性

