#coding=utf-8

print("-----------类的__init__()方法-----------")

class Cat:
    #属性 
    
    #创建完一个对象后自动调用这个方法
    def __init__(self,newColor,newWeight): 
        print('我是 init 方法') 
        self.color = newColor
        self.weight = newWeight 
        
    #方法
    def sleep(self,a,b):
        print('睡觉真好','a=%d,b=%d'%(a,b))
    
    def printInfo(self):
        print(self.color)
        print(self.weight)
        
xiaohuamao = Cat("red",5) #创建一个对象
xiaohuamao.sleep(11,33) #调用类的方法,并且传参数

#添加属性(有了init方法就不需要这样了)
'''xiaohuamao.color = 'red'
   xiaohuamao.weight = 5 #kg'''

#获取小花猫对象的属性
xiaohuamao.printInfo()


