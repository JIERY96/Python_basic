#coding=utf-8
#函数-全局变量
print ("----------函数-全局变量-----------")

num = 100 #在函数的外边定义的变量就叫全局变量

def test1():
    global num #为了改变全局变量的值
    print(num)
    num += 2
    print(num)
    
def test2():
    print(num)
    
test1()
test2()

#全局变量的优点：安全性、其他函数可以直接用
