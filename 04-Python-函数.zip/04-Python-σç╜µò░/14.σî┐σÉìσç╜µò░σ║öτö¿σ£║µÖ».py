#coding=utf-8

print ("----------匿名函数应用场景-----------")

#应用场合：1.自己定义函数
def fun(a,b,opt):
    print("a = :",a)
    print("b = :",b)
    print("Result = :", opt(a,b))   
    
fun(1,2, lambda x, y: x+y)

#应用场合：1.作为内置函数的参数
stus = [
        {"name":"DDD", "age":25},
        {"name":"ABD", "age":22},
        {"name":"AEC", "age":18}
       ]
#按 name 排序
stus.sort(key = lambda x:x['name'])
print(stus)

#按 age 排序
stus.sort(key = lambda x:x['age'])
print(stus)
