#coding=utf-8
#名片管理器

# 定义一个列表来保存学生数据
stuInfos = []

#全局变量
newName = ''
newGender = ''
newTel = ''

def printMenu():
    print("--------------学生管理系统--------------")
    # 1.打印功能提示
    print("="*40)
    print("1.添加学生信息")
    print("2.删除学生信息")
    print("3.修改学生信息")
    print("4.查询学生信息")
    print("5.显示所有学生信息")
    print("0.退出系统")
    print("="*40)
    
def getInfo():
    #改变全局变量的值
    #global newName
    #global newGender
    #global newTel
    
    #提示并获取学生的姓名
    newName = input ("请输入新学生的姓名：")
    #提示并获取学生的性别
    newGender = input ("请输入学生性别(男/女):")
    #提示并获取学生的手机号
    newTel = input("请输入学生电话号码：")
    
    # 通过“列表”的方式吧数据整合成一个整体，然后返回
    #return [newName,newGender,newTel]
    # 通过”元祖“的方式吧数据整合成一个整体，然后返回
    return (newName,newGender,newTel)1
#return {'name':newName,'gen':newGender,'tel':newTel}
         
def addstuInfo():

    result = getInfo() #['aaa','nan','10010']
      
    newInfo = {}
    newInfo['姓名'] = result[0]
    newInfo['性别'] = result[1]
    newInfo['电话'] = result[2]
    #如果要用返回字典的值的话
    #newInfo['姓名'] = result['name']
    #newInfo['性别'] = result['gen']
    #newInfo['电话'] = result['tel']
    
    stuInfos.append(newInfo)         

def editStuInfo():
    
    # 3.1修改学生的信息
    # 提示并获取需要修改的学生姓名
    stuid = int(input("请输入要修改学生的序号:"))
        
    result = getInfo()
        
    stuInfos[stuid-1]['姓名'] = result[0]
    stuInfos[stuid-1]['性别'] = result[1]
    stuInfos[stuid-1]['电话'] = result[2]

def displayStuInfo():
    #print(stuInfos)
    print("="*40)
    print("*****学生的信息如下：*****")
    print("序号  姓名    性别  手机号")
    i = 0
    for temp in stuInfos:
        print("%d    %s    %s    %s"%(i,temp['姓名'],temp['性别'],temp['电话']))
        i+=1


def main():

    while True:
    
        printMenu()

        # 2.获取功能的选择
        key = input("请选择要执行的功能：")
        
        # 3.根据用户的选择，进行相应的操作
        if key == '1':
            # 3.0添加学生信息
            addstuInfo()
            
        elif key == '3':
            #修改学生信息
            editStuInfo()
            
        elif key == '5':
            #显示学生信息
            displayStuInfo()


main()     
