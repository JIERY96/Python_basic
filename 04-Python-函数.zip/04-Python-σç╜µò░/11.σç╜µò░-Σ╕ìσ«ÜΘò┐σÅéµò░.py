#coding=utf-8
#函数-参数3
print ("----------函数-参数3-----------")

#不定长参数

def fun(a,b,*args, **kwargs):
   
   print("a = :",a)
   print("b = :",b)
   print("元祖：",args)
   print("字典：")
   for key, value in kwargs.items():
        print (key, "=",value) 
   
fun(1,2,3,4,5, m=6,n=7,p=8)#注意传递的参数对应

'''
加 '*' 的变量 args 会存放所有未命名的变量参数，args -->元祖
加 '**'的变量 kwargs 会存放命名参数，即形如 key = value。
kwargs -->字典
'''
