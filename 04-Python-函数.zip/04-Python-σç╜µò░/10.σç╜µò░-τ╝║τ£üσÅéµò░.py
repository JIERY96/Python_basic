#coding=utf-8
#函数-参数2
print ("----------函数-参数2-----------")

#缺省参数

def printInfo(name,age = 35):#缺省参数
    
    print ("name:",name)
    print ("age:",age)

printInfo(name = 'jiery')

printInfo(age = 9, name ='shirui')

# 缺省参数：
# 1.带有默认值的缺省参数一定要位于参数列表最后面

