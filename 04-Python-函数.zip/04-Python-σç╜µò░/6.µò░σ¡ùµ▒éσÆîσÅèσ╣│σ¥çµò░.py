#coding=utf-8
#函数的练习
print ("----------函数的练习-----------")

#定义一个函数，完成三个数的求和
def addNum(a,b,c):
    result = a+b+c
    return result
    
def averageNum(A,B,C):
    result = addNum(A,B,C) #调用加法函数
    average = result/3
    return average    
    
result = averageNum(1,2,3) #调用求平均值函数
print(result)
