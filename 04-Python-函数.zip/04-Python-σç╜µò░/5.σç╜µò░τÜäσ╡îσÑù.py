#coding=utf-8
#函数的嵌套
print ("----------函数的嵌套-----------")

def B():
    print("--->B 已经开始执行")
    print("--->B 已经结束执行")
    
def A():

    print("A 已经开始执行<---")
    
    B()
    
    print("A 已经结束执行<---")

A()
