#coding=utf-8
#函数
print ("----------函数-----------")

'''
def 函数名():
函数默认不执行，需要被调用[ 函数名() ]
函数只需要定义一次，但它可以被执行 n 次
'''

def printmy ():
    print("my name is jiery")
 
#调用函数   
printmy()


'''
函数的文档说明(注释函数，用"")：
def printmy ():
    "打印我的名字的函数"
    print("my name is jiery")

'''

