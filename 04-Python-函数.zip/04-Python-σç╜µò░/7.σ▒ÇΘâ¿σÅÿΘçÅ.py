#coding=utf-8
import time
#函数-局部变量
print ("----------函数-局部变量-----------")

def test1():
    num =100
    print(num)
    
def test2():
    num = 200
    print(num)
    time.sleep(1) #休息一秒钟
    num = num +100
    print(num)

def test3():
    print(num)
    
test1()
test2()
test3()

#局部变量：在函数内部定义的变量就叫局部变量
#局部变量只在定义它的函数中有效，出了这个函数，就没用了
#形参也是局部变量
