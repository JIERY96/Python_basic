#coding=utf-8
#函数-参数
print ("----------函数-参数-----------")

#想要一个函数更通用，需要设置参数

'''
def sum2num (num1,num2): #定义的参数叫“形参”
    
    print(num1 + num2)
    
sum2num(431,4541) #传递的参数叫“实参”
'''


def add2num(num1,num2):
    print("俩个数字的和为%d："%(a+b))

a = int(input("请输入第一个数字:"))
b = int(input("请输入第二个数字:"))

add2num(a,b)

