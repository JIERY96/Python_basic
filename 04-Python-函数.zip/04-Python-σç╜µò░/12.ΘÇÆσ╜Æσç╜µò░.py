#coding=utf-8
#函数-递归函数
print ("----------递归函数-----------")
#如果一个函数在内部不调用其他函数，而是自己本身的话，就叫递归函数

#计算阶乘：n! = 1*2*3*4....*n
'''
#解决办法一：使用循环来完成
def calNum(num):
    i = 1
    result = 1
    while i<=num:
        result *= i
        i += 1
    return result
'''
#解决办法二： 使用递归函数来完成
def calNum1(num):
    if num>=1:
        result = num *calNum1(num-1) #调用自己
    else:
        result = 1
    return result
        
ret = calNum1(10)
print(ret)
