#coding=utf-8
#匿名函数

print ("----------匿名函数-----------")

#用 lambda 创建小型匿名函数，省略了用def声明函数的标准步骤
# lambda [arg1,[arg2,...argn]]:expression --->语法

sum = lambda arg1, arg2: arg1+arg2

#调用函数
print("Value of total:",sum(10,20))
print("Value of total:",sum(100,8))

'''
lambda 函数能接收任何数量的参数，但只能返回一个表达式的值
匿名函数不能直接调用print，因为 lambda 需要一个表达式
'''

