#coding=utf-8
#while嵌套

print ("----------while 嵌套-----------")

i = 1
while i <= 5:

    #print("*" * i) # 方法一
    
    j = 1 #方法二
    while j <= i: 
        print("* ", end='')
        j+=1
    print(" ") #换到下一行
    i+=1
    
