#coding=utf-8
#else-if

print ("----------else-if-----------")

gender=int(input("请输入你的性别：（1：男， 2：女 3：人妖）"))

if gender == 1:
    print ("可以做苦力")
elif gender== 2:
    print ("可以做家务")
elif gender == 3:
    print ("既可以做苦力，也可以做家务")
else:
    print (".......你不适合在地球")
    
