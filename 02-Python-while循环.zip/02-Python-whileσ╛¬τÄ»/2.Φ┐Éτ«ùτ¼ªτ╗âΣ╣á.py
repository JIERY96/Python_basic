#coding=utf-8
#练习

print ("----------逻辑运算符练习-----------")

num = input ("请输入一个数字：（0-9）")
if num>="4" and num<"7":
    print("去办公室领奖")
  
    
'''
非（取反）----> not
'''
num1 = int(input ("请输入一个数字：（0-9）"))
if not(num1>=4 and num1<7):
    print("去办公室领奖")
    
