#coding=utf-8
#输出偶数

print ("----------输出偶数-----------")

i = 0

while i < 100:
    if i%2 == 0: #奇数的是！=0
        print (i)
    i+=1

 
