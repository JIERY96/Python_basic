#coding=utf-8
#if嵌套

print ("----------if嵌套-----------")

ticket  = 1 # 1 表示有车票
length = 20 # 超过10cm禁止携带 

if ticket == 1:
    print("可以进入候车厅，等待列车到来")
    if length <= 10:
        print("通过安检，好紧张！！ 可以上车了")
    else:
        print("没有通过安检")
else:
    print("请先购买车票，然后再来检票")
    
    
    
