#coding=utf-8
#逻辑运算符

print ("----------逻辑运算符-----------")

# 1. 提示并获取用户名
userName = input("请输入用户名：")

# 2. 提示并获取密码
passwd = input("请输入密码：")

# 3. 判断用户名和密码都相等，根据判断结果显示信息
if userName =="shirui" and passwd == "123456":
    print ("登录成功！！！")
else:
    print ("登录失败！！！，请重试")

'''
并且 and
或者 or
'''
