#coding=utf-8
import random
#猜拳游戏 + while

print ("----------猜拳游戏 + while -----------")

while True:
    # 1. 提示用户并获取一个数字
    p =int(input("请选择 剪刀：0 石头：1 步：2(按9退出)\n"))
    if p==9:
        break
    
    # 2. 让电脑产生一个数字
    c = random.randint(0,2)
    #print("computer--> %d"%c)

    # 判断输赢， 并产生相应的结果
    if(p==0 and c==2)or(p==1 and c==0)or(p==2 and c==1):
        print("\n你赢了!!!\n")
    elif p == c:
        print("\n平局！不要走，决战到天亮\n")
    else:
        print("\n输了，洗洗手再来吧!!!\n")
