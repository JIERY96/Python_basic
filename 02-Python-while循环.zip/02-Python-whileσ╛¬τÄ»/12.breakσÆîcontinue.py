#coding=utf-8
# break 和 continue

print ("---------《break 和 continue》----------")
'''
i = 0
while i < 10:
    i+=1
    if i == 5:
       break
    print(i)
   
'''  
i = 0
while i < 10:
    i+=1
    if i == 5:
       continue
    print(i)
     
# break: 直接跳过之后的代码
# continue: 跳过当前次数到 while 循环，继续执行后续的代码

# while 嵌套的话，直接截图画框法找 break 所断的代码

