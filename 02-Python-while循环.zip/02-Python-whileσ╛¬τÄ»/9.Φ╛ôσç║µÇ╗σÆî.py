#coding=utf-8
#输出总和

print ("----------输出总和-----------")

i = 1
sumResult = 0

while i<= 100:
    if i %2 == 0: #偶数
        sumResult = sumResult + i
    i+=1

# print 放到 while 外面的原因是：只打最后一次的结果
print("1 到 1000 的和为：%d" %sumResult)


