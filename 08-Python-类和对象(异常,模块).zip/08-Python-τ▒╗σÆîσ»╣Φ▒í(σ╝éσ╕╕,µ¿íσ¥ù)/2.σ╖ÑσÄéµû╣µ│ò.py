#coding-utf-8

print('-------------工厂方法--------------')

#工厂方法: 定义一个工厂, 工厂里面有方法需要在子类重写去实现

#定义一个基本的 4S 店类
class CarStore(object):

    #仅仅定义方法,并没有实现,具体功能,在子类中实现
    def createCar(object):
        pass
    
    def orderCar(self):
    
        #让工厂根据车的类型生产一辆车
        self.car = self.createCar(typeName)
        self.move()
        self.stop()
        
class Myvi(CarStore):
    
    def createCar(object):
        self.CarFactory = CarFactory()
        return self.CarFactory.createCar(typeName)
        
car = CarStore('雪佛兰')

