#coding-utf-8

print('-------------"__new__()方法"------------')

#单例模式:首先要有一个 __new__() 方法

class Test(object):
    
    #初始化的功能(往往完成对象属性的设置)
    def __init__(self):
        self.num = 100
        print('__init__()方法被调用了')
        print(self)
     
     
    #完成创建一个对象(创建对象其实是__new__方法执行)   
    def __new__(cls):
        print('__new__() 方法被调用了')
        print(cls)
        return super().__new__(cls) #返回创建的对象
        
        
    def __str__(self):
        return 'xxxx'
        
a = Test() #先调用_new_()方法创建对象.然后调用_init_()初始化功能  
print(a.num)
print(a)
