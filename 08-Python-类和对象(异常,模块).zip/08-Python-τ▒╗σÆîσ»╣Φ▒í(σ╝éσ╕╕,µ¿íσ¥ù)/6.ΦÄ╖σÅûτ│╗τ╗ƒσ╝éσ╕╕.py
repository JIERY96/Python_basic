#coding-utf-8

print('------------获取系统异常-------------')

'''
try: #单异常
    print(abc)
    
except NameError as jiery:
    print('产生了一个异常..(%s'%jiery +')')
'''    
    
    

try: #多异常

    #print(abc)
    open ('abc.txt')
    
except (NameError,FileNotFoundError) as jiery:
    print('产生了一个异常..(%s'%jiery +')')
    
    
#要获取系统异常的话, 随便放一个变量, 放系统的异常信息
