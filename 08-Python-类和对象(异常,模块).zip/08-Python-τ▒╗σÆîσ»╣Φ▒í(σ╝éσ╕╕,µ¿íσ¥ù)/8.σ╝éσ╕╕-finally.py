#coding-utf-8

print('------------异常-finally-------------')

try: # 如果产生一个异常,但 except 没有捕获,那么按异常默认方式处理
    open('abc.txt')
    a = 100
    print(a)
 
except NameError: #只要在try中有'NameError',才会执行这个异常处理
    print('捕获到一个异常')
else:
    print('-----1------')#else作用: try 里面没有任何异常就去执行

finally:
    print('----最后执行的事情-----')
      
# finally: 任何情况下一定执行的语句

''' 处理异常的集中方式-总结
try:
    xxx   
except: 产生异常做的事情

else: 没有产生异常做的事情

finally: 任何情况下一定执行的语句
'''
