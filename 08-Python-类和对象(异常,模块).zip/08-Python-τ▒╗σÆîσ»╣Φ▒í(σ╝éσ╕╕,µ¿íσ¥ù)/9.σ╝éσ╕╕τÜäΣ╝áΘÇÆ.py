#coding-utf-8

print('------------异常的传递-------------')

#异常传递: 当一个异常产生的时候,传递的过程

def Test1():
    print('----1-1----')
    print(num)
    print('----1-2----')

def Test2():
    print('----2-1----') 
    Test1()   
    print('----2-2----')

def Test3():
    try:
        print('----3-1----') 
        Test1()   
        print('----3-2----')
    except Exception as result:
        print('捕获到了异常%s'%result)

Test3()

# Test1() 并没有对异常进行处理
# 异常处理机制:程序会一直找异常的处理,最后找不到采用系统默认异常的处理
