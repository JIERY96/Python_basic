#coding-utf-8

print('-------------工厂模式--------------')

#解耦
class StrawberryCake(object):
    def __init__(self, taste='草莓味'):
        self.taste = taste
        
class MangoCake(object):
    def __init__(self, taste='芒果味'):
        self.taste = taste

class CakeFactory(object):
    def CreateCake (self, tasteOfCake):
         if tasteOfCake == '草莓味':
            cake = StrawberryCake()
         elif tasteOfCake == '芒果味':
            cake = MangoCake()
                      
         return cake

class CakeStore(object):

    def __init__(self):
        self.factory = CakeFactory()
        
    def Taste(self, tasteOfCake):
        #调用工厂
        cake = self.factory.CreateCake(tasteOfCake)
        print('品尝味道:%s'%cake.taste)
        
mystore = CakeStore()
mystore.Taste('草莓味')
