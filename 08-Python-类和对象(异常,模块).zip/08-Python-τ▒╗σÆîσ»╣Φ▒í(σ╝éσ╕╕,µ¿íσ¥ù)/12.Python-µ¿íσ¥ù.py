#coding-utf-8

print('-----------模块-----------')

def test():
    print('hahahah')
 
#测试
if __name__ == '__main__':

    print(__name__)
    test()
    
        
# __name__: 自己执行本模块代码的话, __name__ 会等于 '__main__'
# 如果这个模块被导入的话, __name__ 会等于 模块名(文件名)
