#coding-utf-8
import time
print('------------捕获所有异常-------------')

try:
    '''
    while True:
        print('aaaaaaaa')
        time.sleep(1)
    '''
    #print(abc)
    open ('abc.txt')
    
except Exception as result: 
    print('哥们,有异常!')
    print(result)

# Exception 表示所有异常类的基类(父类)
# 一般不会捕获所有异常

try: # 如果产生一个异常,但 except 没有捕获,那么按异常默认方式处理
    a = 100
    print(a)
 
except NameError: #只要在try中有'NameError',才会执行这个异常处理
    print('捕获到一个异常')
else:
    print('-----1------')#else作用: try 里面没有任何异常就去执行
