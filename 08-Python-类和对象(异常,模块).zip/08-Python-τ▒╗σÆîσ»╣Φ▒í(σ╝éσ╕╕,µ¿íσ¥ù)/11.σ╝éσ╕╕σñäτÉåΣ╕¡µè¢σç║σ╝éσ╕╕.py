#coding-utf-8

print('-----------异常处理中抛出异常-----------')

class Test(object):
    def __init__(self, switch):
        self.switch = switch
    
    def calculate(self, a,b):
        try:
            return a/b
            
        except Exception as result:
         
            if self.switch:
                print('捕获到异常,信息如下:')
                print(result)
            else:
#重新抛出这个异常(用raise),此时不会被异常处理捕获到,触发默认异常处理
                raise


a = Test(True)
a.calculate(11,0)

print('-----------分割线-----------')

a.switch = False
a.calculate(11,0)
