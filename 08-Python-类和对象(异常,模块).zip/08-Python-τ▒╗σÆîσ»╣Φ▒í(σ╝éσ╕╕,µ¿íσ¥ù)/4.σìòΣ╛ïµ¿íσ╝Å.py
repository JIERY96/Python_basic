#coding-utf-8

print('------------单例模式-------------')

class Singleton (object):

    #类属性
    __instance = None
    
    # 完成单例的控制
    def __new__(cls):
        #如果之前没有创建
        if cls.__instance == None:
             # object 也可以写成 super()
             cls.__instance = object.__new__(cls) #创建对象
        return cls.__instance
        

a = Singleton()
print(a)

b = Singleton()        
print(b)


#单例:只创建一个对象,往后再创建对象的话,返回之前的对象
# a 和 b 返回的对象是一样的
