#coding-utf-8

print('------------捕获异常-------------')

# try .... except....


try:
    # 可能出现异常的代码
    print (abc)
    open('abc.txt')
  

# 一个 except 处理多个异常并且返回一个处理方式 
except (NameError,FileNotFoundError):

    # 处理的方式
    print('没有定义变量....')



'''      
except FileNotFoundError:
    
    print('没有找到文件....')
'''
