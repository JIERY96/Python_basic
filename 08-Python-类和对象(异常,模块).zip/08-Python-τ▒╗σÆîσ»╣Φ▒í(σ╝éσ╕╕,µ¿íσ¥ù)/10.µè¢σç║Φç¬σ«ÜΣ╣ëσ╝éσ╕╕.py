#coding-utf-8

print('------------抛出自定义异常-------------')

class ShortInputException(Exception):

    '''自定义的异常类'''
    def __init__(self, length, atleast):
        self.length = length
        self.atleast = atleast

try:
    s = input('请输入账户名:')
    if len(s) < 3:
        
        # raise 引发一个你自己定义的异常
        raise ShortInputException(len(s), 3)
       

except ShortInputException as result:
    print('ShortInputException: 输入长度:%d, 至少长度:%d'%(result.length,result.atleast))

else:
    print('没有异常发生')
    print('可以继续下面的功能了')
        
 
