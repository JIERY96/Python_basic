#coding=utf-8
#字典的遍历

print ("-----------字典的遍历-----------")

myInfo = {'姓名':'jiery','性别':'男','年龄':'21'}

for temp in myInfo.keys():
    print(temp)
    
for temp1 in myInfo.values():
    print(temp1)
    
for temp2 in myInfo.items():
    print(temp2)


for temp3 in myInfo.items():
    print("%s:%s"%(temp3[0],temp3[1]))
  
    
#补充：列表的操作
#[11,22,33] + [44,55,66] = [11,22,33,44,55,66]
#[1,2,3]*2 = [1,2,3,1,2,3]

