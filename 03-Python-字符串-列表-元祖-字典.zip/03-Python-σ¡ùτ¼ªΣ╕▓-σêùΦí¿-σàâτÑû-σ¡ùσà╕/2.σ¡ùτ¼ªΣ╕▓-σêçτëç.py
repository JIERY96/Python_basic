#coding=utf-8
#字符串-切片

print ("----------字符串-切片-----------")


nickname = 'abcdefghlafdsafsadfdsqfdsgsdagadsgasd'

# 用 while 
i = 0
while i <1:
    print(nickname[::5])
    i+=1

len(nickname)

# [起始位置:结束位置:步长] 步长：直接跳跃的具体的长度
# [:::-1] 表示反转字符串 abc --> cba 
# [-2] 表示倒数第二个字符
