#coding=utf-8
#列表的sort/reverse操作

print ("---------列表的sort/reverse操作---------")
    
nums = [11,33,55,7,4,5556,7886,343,9]    

#nums.sort() #从小到大排
#nums.sort(reverse = True) # 从大到小排
nums.reverse() # 逆排序(倒序)

print(nums)

# sort 也可以对字母的排序 (实质是对 ASCII 码的排序)
