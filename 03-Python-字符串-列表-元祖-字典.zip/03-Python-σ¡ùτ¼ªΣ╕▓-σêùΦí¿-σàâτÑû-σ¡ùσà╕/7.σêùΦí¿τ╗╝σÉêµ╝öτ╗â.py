#coding=utf-8
#定义一个列表，用来储存所有的名字
names = []

while True:
    print ("----------列表综合演练-----------")
    print ("="*20)
    print ("欢迎使用 xxx 系统")
    print ("1. 添加新名字")
    print ("2. 删除一个名字")
    print ("3. 修改一个名字")
    print ("4. 查询名字")
    print ("5. 所有名字")
    print ("0. 退出系统")
    print ("="*20)

    # 获取要操作的数字
    key = input ("请输入功能：")

    if key == "1":
        username = input ("请输入要添加的名字：")
        names.append(username)
    elif key == "2":
        print(names)
        delname = input("请输入要删除的名字:")
        names.remove(delname)   
    elif key == "3":
        checkname = input("请输入要修改的名字:")
        if checkname in names:
            editname = input("请输入要修改的名字:")
            names.append(editname)
            names.remove(checkname)
        else:
            print("没有找到要修改的名字!")
    elif key == "4":
        findName = input("请输入要查询的名字:")
        if findName in names:
            print(findName)
    elif key == "5":
         print(names)
    elif key == "0":
        exit()


        
