print ("----------字符串的常见操作-----------")

myStr = 'hello python and shirui andhello'

myStr.find("and") # 获取字符的位置
myStr.rfind("python") # 从右往左找，可以获取文件后缀
myStr.index("shirui") # 输出“shirui” 的位置
myStr.rindex("and") #  从右往左输出 and 的位置
myStr.count("shi") #  输出 “shi” 的个数
myStr.count("shi",3,34) # 从 3-34 的位置找 “shi”
myStr.replace("he","He") # 把“he” 换成 “He”，He只是中间产物
myStr1 = myStr.replace("he","He")#保存了 ”He“
myStr.replace("he","He"，1) #只替换一次。不写则全部替换
myStr.split() #切割 【可以用于词语分割，统计等
myStr.splitlines() #按照换行符（\n）拆各个字符
myStr.capitalize() # 第一个字符大写
myStr.startswith("") #判断是否为 ”xx“ 开头
myStr.endswith("") #判断是否以 ”xx“ 结尾
myStr.lower() # 字符串全部转为小写
myStr.upper() # 字符串全部转为大写
myStr.ljust(2) # 字符串靠左显示，空2格
myStr.rjust(2) # 字符串靠右显示，空2格
myStr.center() # 字符串居中
myStr.lstrip(" ") # 删除字符串左边边的空格
myStr.rstrip(" ") # 删除字符串右边的空格
myStr.strip(" ") #删除俩端的空格
myStr.partition('and')#把myStr以and 分割成 and前 and and后
myStr.isalpha() # 判断字符串是否全部为字母，不是返回false
myStr.isdigit() # 如果包含数字则返回 true
myStr.isalnum() # 若所有字符都是字母或数字，则返回 ture
myStr.isspace() # 若字符中包含空格，则返回 ture 否则返回false
str1.join(myStr) #str1 = '_' 用_连接各个字符串


