#coding=utf-8
#字典的操作 

print ("-----------字典的操作-----------")

myInfo = {'姓名':'宝强','性别':'男','妻子':'张女士'}

# 增加
myInfo['money'] = '10亿'
# 删除
del myInfo ['妻子']
# 修改
myInfo['性别'] = '女'
# 查询 
print (myInfo['money'])

# 字典的常见操作
print(len(myInfo)) 
print(myInfo)
print(myInfo.keys()) #打印键
print(myInfo.values())
print(myInfo.items())

# myInfo.clear() 清除字典
