#coding=utf-8

print ("----------列表练习-----------")

# 1. 定义一个列表
nameList = ["jason",'bryan','sohai','jiery','rose']
# 2. 获取要查询的名字
inputname = input("请输入您的名字：")
# 3. 判断是否存在
checkResult = 0
for name in nameList:
    if name == inputname:
        checkResult = 1
        break #如果在前面已经找到，那结束循环，提升效率       
if checkResult == 1:
    print("找到了")
else:
    print("没有找到")
'''
#第二种方法
if inputname in nameList:
    print("找到了")
else:
    print("没有找到")'''
        
