#coding=utf-8
#for循环

print ("----------for循环-----------")

name = 'shirui'

print (name)

for temp in name: 
    print (temp)


nickname = 'jiery'
# 用 while 
i = 0
while i <4:
    print(nickname[i])
    i+=1

'''
for 临时变量 in 字符串: 
    print (临时变量)
'''
