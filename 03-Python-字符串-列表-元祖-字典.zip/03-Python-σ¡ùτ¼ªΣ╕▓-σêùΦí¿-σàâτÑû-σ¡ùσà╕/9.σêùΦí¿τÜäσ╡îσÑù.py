#coding=utf-8
import random

print ("---------列表的嵌套---------")

#场景：三个办公室，八位老师等待分配，完成随机分配
# 定义一个列表保存三个办公室
offices = [[],[],[]]

# 定义一个列表来保存 8 为老师的名字
teachers = ['A','B','C','D','E','F','G','H']

# 随机把 8 名老师 添加到 第一个列表中
for name in teachers:
    randomNum = random.randint(0,2)
    offices[randomNum].append(name)

#print(offices)
i= 1
for room in offices :
    #print(room)
    print("办公室%d里面的老师姓名是："%i)
    for name in room:
        print(name,end="")
    print("")
    i+=1
