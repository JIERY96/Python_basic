#coding=utf-8
#字典 {key：value} 

print ("------------字典------------")

info = {"姓名":"jiery",'年龄':'21'}

print(type(info))

print(info['姓名'])

print(info)

# value 可以相同， 但是 key 不可以相同

'''
字典的操作：
1. 增
2. 删
3. 改
4. 查
'''
