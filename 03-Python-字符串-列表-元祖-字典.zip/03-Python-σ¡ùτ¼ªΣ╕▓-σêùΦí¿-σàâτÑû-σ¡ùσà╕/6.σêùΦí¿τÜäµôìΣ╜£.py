#coding=utf-8
#列表操作

print ("----------列表操作-----------")

names = ['jason','bryan','cheng','rose','jiery']

employee = ['小王','小李']

names.append("shirui") #末尾添加
names.insert(1, "AAA") #随意插入位置
names.extend(employee) #将另一个列表的元素插入当前列表中
names.append(employee) #列表嵌套
names[1] = 'Bryan' # 修改列表中的元素
#if xxx in name: # 查找元素
#del names[1] #删除指定元素
#names.pop() #删除最后一个元素
#names.remove("bryan") #删除元素

print(names)
print(names[9])
print(names[8][1]) #取出“小李” 的 “李”
