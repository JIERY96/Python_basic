#coding=utf-8
#列表

print ("----------列表-----------")

names = ["jiery","bryan","jason","100"] #定义一个列表

print(names)

# 下标
print(names[0])

#遍历列表-for
for temp in names:
    print(temp)

#遍历列表-while
i =0
while i < len(names):
    print(names[i])
    i+=1

type(names) # 是一个 list
# Python 的列表（list）可以保存 n 个数据， 而且数据类型没有限制


